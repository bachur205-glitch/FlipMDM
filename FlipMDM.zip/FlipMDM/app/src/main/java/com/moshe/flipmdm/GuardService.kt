package com.moshe.flipmdm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder

/**
 * Stays running so it can catch the shutdown signal (Android only sends it
 * to running apps) and un-hide system apps before the phone powers off.
 */
class GuardService : Service() {

    private val shutdownReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            BootSafe.beforeShutdown(context)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "MDM protection", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Flip MDM is active")
            .setOngoing(true)
            .build()
        startForeground(1, n)

        val filter = IntentFilter(Intent.ACTION_SHUTDOWN)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(shutdownReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(shutdownReceiver, filter)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        try { unregisterReceiver(shutdownReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL = "guard"
        fun start(c: Context) {
            c.startForegroundService(Intent(c, GuardService::class.java))
        }
    }
}
